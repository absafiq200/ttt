import boto3
import json
from http_util import response_hdr


pinpoint = boto3.client("pinpoint")

def getSegmentPP():
    try:
    
        resp = pinpoint.get_segment(
                    ApplicationId="6961dcd9bff04b21970d9380310d4c57",
                    SegmentId="782839d6e00a470eb94b5ea03ab1e1ee"
                )
        print(resp)
        return resp
    except Exception as er:
        print(er)    