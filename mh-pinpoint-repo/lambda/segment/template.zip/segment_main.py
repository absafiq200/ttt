import json,os
from cust_date_util import getCurrentDateTime
from aws_lambda_powertools import Logger, Tracer
from aws_lambda_powertools.event_handler.router import APIGatewayHttpRouter
from aws_lambda_powertools.event_handler import (Response,content_types)
from pinpoint_util import getSegment
tracer = Tracer()
logger = Logger()
router = APIGatewayHttpRouter()

@router.post("/segment/<type>/get")
@tracer.capture_method   
def getSegment(type):
    return getSegment()
